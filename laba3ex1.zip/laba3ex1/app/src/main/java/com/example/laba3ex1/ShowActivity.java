package com.example.laba3ex1;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ShowActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_activity);

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        Cursor cursor = dbHelper.getAllData();

        TextView textViewData = findViewById(R.id.textViewData);
        StringBuilder sb = new StringBuilder();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
                String fio = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_FIO));
                long timestamp = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ADDED_TIME));
                SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault());
                String formattedDate = sdf.format(new Date(timestamp));

                sb.append("ID: ").append(id).append("\n");
                sb.append("ФИО: ").append(fio).append("\n");
                sb.append("Время добавления: ").append(formattedDate).append("\n\n");
            } while (cursor.moveToNext());
        } else {
            sb.append("Нет данных");
        }

        cursor.close();
        textViewData.setText(sb.toString());
    }
}